function write_gnuPLOT_file(f_Mode,f_TxtFile,f_Text1,f_NPoints,f_FreqData,f_BinInterval,NNormals,f_increment,f_minFraction)
%WRITE_GNUPLOT_FILE Create the file needed to run gnuPLOT and generate the contoured data grasp.
%   Mary had a little lamb. And the doctor fainted.
%
%   Write the .PLT file needed to run gnuPLOT for the data contained in the
%   corresponding .txt file.  
%   D. Rickman, Jan 27, 2014
% Mode = 1 for Plane of Projection.
% Mode = 2 for Plane of Section.

Ftxt{500} = 'a'; % Preallocate the array

% Define the names of the .plt, .pdf files.
if f_Mode == 1
    FTxt0 = 'Plane of Projection Model Results';
    FTxt6 = '_PofProj.plt';
    FTxt8 = '_PofProj.pdf'; 
else % f_Mode ==2
    FTxt0 = 'Plane of Section Model Results';
    FTxt6 = '_PofSect.plt';
    FTxt8 = '_PofSect.pdf';
end
    
pltFileName = [f_Text1,FTxt6];
pltFileName = strrep(pltFileName,' ', '_');
fileID    = fopen(pltFileName,'w');

pdfFileName = [f_Text1,FTxt8];
pdfFileName = strrep(pdfFileName,' ', '_');

TLine = 0;
LLine = 0;
TLine = TLine+1;
Ftxt{TLine}  = ['# ',FTxt0,'For the solid ',f_Text1];
TLine = TLine+1;
Ftxt{TLine}  = '# Graph Relative Frequency of Aspect Ratio vs Heywood Factor using gnuplot.';
TLine = TLine+1;
Ftxt{TLine}  = '# The path is set to /Users/doug2/Documents/MATLAB/.  Edit the "path1" and "path2 lines to change this.';
TLine = TLine+1;
Ftxt{TLine}  = '# This script designed by Doug Rickman, Jan 30, 2014';
TLine = TLine+1;
Ftxt{TLine}  = '# set terminal pdf enhanced dashed dl 3 size 7,7 '; % This is included to make it easier for others to use this command file.
TLine = TLine+1;
Ftxt{TLine}  = 'set terminal pdfcairo enhanced color dashed dashlength 3 size 7,7';
TLine = TLine+1;
Ftxt{TLine}  = 'set macros';
TLine = TLine+1;
Ftxt{TLine}  = 'dquote    = ''"''';
TLine = TLine+1;
Ftxt{TLine}  = 'path1     = "/Users/doug2/Documents/"';
TLine = TLine+1;
Ftxt{TLine}  = 'path2     = "MATLAB/"';
TLine = TLine+1;
Ftxt{TLine}  = ['outfile   = "',pdfFileName,'"'];
TLine = TLine+1;
Ftxt{TLine} = ['infile    = "',f_TxtFile,'"'];
TLine = TLine+1;
Ftxt{TLine} = 'set output @dquote@path1@path2@outfile@dquote';
TLine = TLine+1;

Ftxt{TLine}= 'set style line 1  lt 0  lw 3  lc rgbcolor ''black''   # dot';
TLine = TLine+1;
Ftxt{TLine}= 'set style line 2  lt 1  lw 3  lc rgbcolor ''black''   # solid';
TLine = TLine+1;
Ftxt{TLine}= 'set style line 3  lt 2  lw 8  lc rgbcolor ''grey90''  # long dash';
TLine = TLine+1;
Ftxt{TLine}= 'set style line 4  lt 3  lw 8  lc rgbcolor ''grey90''  # short dash';
TLine = TLine+1;
Ftxt{TLine}= 'set style line 5  lt 4  lw 3  lc rgbcolor ''black''   # long short long short';
TLine = TLine+1;
Ftxt{TLine}= 'set style line 6  lt 5  lw 3  lc rgbcolor ''black''   # long short short long';
TLine = TLine+1;
Ftxt{TLine}= 'set style line 13 lt 2  lw 11 lc rgbcolor ''black''   # long dash';
TLine = TLine+1;
Ftxt{TLine}= 'set style line 14 lt 3  lw 11 lc rgbcolor ''black''   # short dash';

TLine = TLine+1;

Ftxt{TLine}= 'set grid';
TLine = TLine+1;
Ftxt{TLine}= 'set cntrparam bspline';
TLine = TLine+1;
Ftxt{TLine}= 'set cntrparam order 10';

TLine = TLine+1;
Ftxt{TLine}= 'set view equal xyz';
TLine = TLine+1;
Ftxt{TLine}= 'set view 0,0,1.5,1';
TLine = TLine+1;
Ftxt{TLine}= 'unset xlabel';
TLine = TLine+1;
Ftxt{TLine}= 'unset ylabel';
TLine = TLine+1;
Ftxt{TLine}= 'unset zlabel';
TLine = TLine+1;
Ftxt{TLine}= 'unset key';
TLine = TLine+1;
Ftxt{TLine}= 'unset zrange';
TLine = TLine+1;
Ftxt{TLine}= 'unset colorbox';
TLine = TLine+1;
Ftxt{TLine}= 'set palette defined (  0 "black", 0.1 "black", 0.1 "dark-magenta", 1 "blue", 2 "forest-green", 3 "orange", 4 "red", 5 "black")';
TLine = TLine+1;
Ftxt{TLine}= 'set xrange [0:1]';
TLine = TLine+1;
Ftxt{TLine}= 'set yrange [0:1]';
TLine = TLine+1;
Ftxt{TLine}= 'set zrange [0:100]';
TLine = TLine+1;
Ftxt{TLine}= 'unset ztics';
TLine = TLine+1;
Ftxt{TLine}= 'set mxtics 2';
TLine = TLine+1;
Ftxt{TLine}= 'set mytics 2';
TLine = TLine+1;
Ftxt{TLine}= 'set multiplot';
TLine = TLine+1;
Ftxt{TLine}= 'set size 0.95, 0.95';
TLine = TLine+1;
Ftxt{TLine}= 'set origin 0.0, 0.01';

% If the title does not contain the word "Dimensions" use it as is.  Otherwise split it in half, making an
% upper and lower line.
k = strfind(f_Text1,'Dimensions'); 
if isempty(k); 
    TLine = TLine+1;
    LLine = LLine+1;
    Ftxt{TLine}= ['set label ',num2str(LLine),' ''',f_Text1,'''            font ''Helvetica,30'' at  0.5 ,  1.1 , 0 center'];
else
    Text  = strsplit(f_Text1,' - ');
    TLine = TLine+1;
    LLine = LLine+1;
    Ftxt{TLine}= ['set label ',num2str(LLine),' ''',Text{1},'''            font ''Helvetica,30'' at  0.5 ,  1.10 , 0 center'];
    TLine = TLine+1;
    LLine = LLine+1;
    Ftxt{TLine}= ['set label ',num2str(LLine),' ''',Text{2},'''            font ''Helvetica,30'' at  0.5 ,  1.04 , 0 center'];
end

TLine = TLine+1;
LLine = LLine+1;
Ftxt{TLine}= ['set label ',num2str(LLine),' ''n Total   {\\011}= ',num2str(f_NPoints),'''           font ''Helvetica,20'' at  0.15,  0.23 , 0']; % Note escaping of \\ to insert a tab
TLine = TLine+1;
LLine = LLine+1;
Ftxt{TLine}= ['set label ',num2str(LLine),' ''Bin Size  {\\011}= ',num2str(f_BinInterval),'''       font ''Helvetica,17'' at  0.15,  0.18']; % Note escaping of \\ to insert a tab

if f_Mode == 2 % Add labels for number of surface normals and number of slices.
TLine = TLine+1;
LLine = LLine+1;
Ftxt{TLine}= ['set label ',num2str(LLine),' ''N Normals{\\011}= ',num2str(NNormals),'''            font ''Helvetica,17'' at  0.15,  0.14'];
TLine = TLine+1;
LLine = LLine+1;
Ftxt{TLine}= ['set label ',num2str(LLine),' ''N Slices  {\\011}= ',num2str(f_increment),'''         font ''Helvetica,17'' at  0.15,  0.10'];
end

TLine = TLine+1;
LLine = LLine+1;
Ftxt{TLine}= ['set label ',num2str(LLine),' ''Aspect Ratio''                   font ''Helvetica,28'' at  0.5 ,  -0.09, 0 center'];
TLine = TLine+1;
LLine = LLine+1;
Ftxt{TLine}= ['set label ',num2str(LLine),' ''Heywood Factor''                 font ''Helvetica,28'' at -0.05 ,  0.5 , 0 center rotate by 90'];
TLine = TLine+1;
LLine = LLine+1;
Ftxt{TLine}= ['set label ',num2str(LLine),' ''Normalized Frequency''           font ''Helvetica,12'' at screen 0.10,  0.02, 0 left'];
if f_minFraction ~=0
    TLine = TLine+1;
    LLine = LLine+1;
    Ftxt{TLine}= ['set label ',num2str(LLine),' ''Polygons < ',num2str(f_minFraction),' of max area dropped'' font ''Helvetica,12'' at screen 0.45,  0.02, 0 center'];
else
    TLine = TLine+1;
    LLine = LLine+1;
    Ftxt{TLine}= ['set label ',num2str(LLine),' ''All polygons kept regardless of size'' font ''Helvetica,12'' at screen 0.45,  0.02, 0 center'];   
end
TLine = TLine+1;
LLine = LLine+1;
Ftxt{TLine}= ['set label ',num2str(LLine),' ''',FTxt0,''' font ''Helvetica,12'' at screen 0.64,  0.02, 0 left'];
TLine = TLine+1;
Ftxt{TLine}= 'set xtics 0.2 format "%%.1f" font ''Helvetica,20'' offset -0.35,-0.3'; % Note the escaping of %
TLine = TLine+1;
Ftxt{TLine}= 'set ytics 0.2 format "%%.1f" font ''Helvetica,20'' offset -0.35,-0.3'; % Note the escaping of %
TLine = TLine+1;
Ftxt{TLine}= 'set surface';
TLine = TLine+1;
Ftxt{TLine}= 'unset contour';
TLine = TLine+1;
Ftxt{TLine}= ' ';

TLine = TLine+1;
Ftxt{TLine}= '# To plot the individual data points turn on the following line. ';
TLine = TLine+1;
Ftxt{TLine}= '# splot @dquote@path1@path2@infile@dquote  index 5 using 1:2:3 with points pointtype 7 lc rgbcolor ''dark-green''  pointsize 0.2 # filled circles';
TLine = TLine+1;
Ftxt{TLine}= ' ';

TLine = TLine+1;
Ftxt{TLine}= '# To plot the bins containing 95%% of the data.  Points are scaled to match the bin size.';
TLine = TLine+1;
Ftxt{TLine}= '# Notice, bins are plotted as points. The plotted bin center is 1/2 bin width down and left of the desired location. ';
TLine = TLine+1;
Ftxt{TLine}= '# This routine shifts the bins to compensate for this.';
TLine = TLine+1;
Ftxt{TLine}= ['splot @dquote@path1@path2@infile@dquote  index 2 using ($1+',num2str(f_BinInterval/2),'):($2+',num2str(f_BinInterval/2),'):($3) with points pointtype 5 lc rgbcolor ''black''  pointsize 0.8    # Hollow squares, used to outline'];
TLine = TLine+1;
Ftxt{TLine}= ['splot @dquote@path1@path2@infile@dquote  index 2 using ($1+',num2str(f_BinInterval/2),'):($2+',num2str(f_BinInterval/2),'):($3) with points pointtype 5 lc rgbcolor ''lemonchiffon''  pointsize 0.60    # solid squares'];
TLine = TLine+1;
Ftxt{TLine}= ' ';

TLine = TLine+1;
Ftxt{TLine}= '# To plot the bins containing 75%% of the data';
TLine = TLine+1;
Ftxt{TLine}= ['splot @dquote@path1@path2@infile@dquote  index 3 using ($1+',num2str(f_BinInterval/2),'):($2+',num2str(f_BinInterval/2),'):($3) with points pointtype 5 lc rgbcolor ''royalblue''  pointsize 0.78 # solid squares'];
TLine = TLine+1;
Ftxt{TLine}= ['splot @dquote@path1@path2@infile@dquote  index 3 using ($1+',num2str(f_BinInterval/2),'):($2+',num2str(f_BinInterval/2),'):($3) with points pointtype 5 lc rgbcolor ''grey60''  pointsize 0.60 # solid squares'];
TLine = TLine+1;
Ftxt{TLine}= ' ';

TLine = TLine+1;
Ftxt{TLine}= '# To plot the bins containing 50%% of the data';
TLine = TLine+1;
Ftxt{TLine}= ['splot @dquote@path1@path2@infile@dquote  index 4 using ($1+',num2str(f_BinInterval/2),'):($2+',num2str(f_BinInterval/2),'):($3) with points pointtype 5 lc rgbcolor ''light-red''  pointsize 0.78 # solid squares'];
TLine = TLine+1;
Ftxt{TLine}= ['splot @dquote@path1@path2@infile@dquote  index 4 using ($1+',num2str(f_BinInterval/2),'):($2+',num2str(f_BinInterval/2),'):($3) with points pointtype 5 lc rgbcolor ''grey20''  pointsize 0.60 # solid squares'];
TLine = TLine+1;
Ftxt{TLine}= ' ';


TLine = TLine+1;
Ftxt{TLine}= 'unset surface';
TLine = TLine+1;
Ftxt{TLine}= 'set contour'; 
CI     = (f_FreqData(1)-f_FreqData(2))/5;
FTxtCI = [num2str(f_FreqData(2),3),', ',num2str(CI,3),', ',num2str(f_FreqData(1),3)];
TLine = TLine+1;
Ftxt{TLine}= ['set cntrparam levels incremental ',FTxtCI];
TLine = TLine+1;
Ftxt{TLine}= ['set cbrange [0.0:',num2str(f_FreqData(1)),']'];

TLine = TLine+1;
Ftxt{TLine}= '# To plot the binned data as contours turn on the following 2 lines. ';
TLine = TLine+1;
LLine = LLine+1;
Ftxt{TLine}= ['# set label ',num2str(LLine),' ''Contour (B,I,E)= ',FTxtCI,'''   font ''Helvetica,17'' at  0.15,  0.06']; % Note escaping of \\ to insert a tab
TLine = TLine+1;
Ftxt{TLine}= ['# splot @dquote@path1@path2@infile@dquote  index 1 using ($1+',num2str(f_BinInterval/2),'):($2+',num2str(f_BinInterval/2),'):($3) w l lw 3 palette'];

TLine = TLine+1;
Ftxt{TLine}= 'set surface';
TLine = TLine+1;
Ftxt{TLine}= 'unset contour';
TLine = TLine+1;
Ftxt{TLine}= ' ';

% Do the ellipse, rectangle and triangle lines
TLine = TLine+1;
Ftxt{TLine}= 'set format xy""';
TLine = TLine+1;
Ftxt{TLine}= 'set xtics 0.1';
TLine = TLine+1;
Ftxt{TLine}= 'set ytics 0.1';
TLine = TLine+1;
Ftxt{TLine}= 'set surface';
TLine = TLine+1;
Ftxt{TLine}= 'unset contour';
TLine = TLine+1;
Ftxt{TLine}= '# To plot the lines for ellipses, rectangles and triangles turn on the following lines. ';
TLine = TLine+1;
Ftxt{TLine}= 'splot @dquote@path1@path2@infile@dquote   index 0 using 1:2:7 w l ls 2  # Ellipse';
TLine = TLine+1;
Ftxt{TLine}= 'splot @dquote@path1@path2@infile@dquote   index 0 using 3:4:7 w l ls 13 # Rectangle';
TLine = TLine+1;
Ftxt{TLine}= 'splot @dquote@path1@path2@infile@dquote   index 0 using 3:4:7 w l ls 3  # Rectangle';
TLine = TLine+1;
Ftxt{TLine}= 'splot @dquote@path1@path2@infile@dquote   index 0 using 5:6:7 w l ls 14 # Isoceles triangle';
TLine = TLine+1;
Ftxt{TLine}= 'splot @dquote@path1@path2@infile@dquote   index 0 using 5:6:7 w l ls 4  # Isoceles triangle';
TLine = TLine+1;
Ftxt{TLine}= 'unset surface';
TLine = TLine+1;
Ftxt{TLine}= 'set contour';
TLine = TLine+1;
Ftxt{TLine}= 'unset multiplot';
TLine = TLine+1;
Ftxt{TLine}= 'exit';

for i = 1:TLine;
    fprintf(fileID,[Ftxt{i},'\n']);
end
fclose(fileID);

end

